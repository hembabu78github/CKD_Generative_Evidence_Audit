$ErrorActionPreference = "Stop"
Write-Host "=== C4-016 environment ==="
python --version
Write-Host "`n=== Integrated C4-006 through C4-016 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-016 deterministic replay and version tracking ==="
python run_c4_016_validation.py
Write-Host "`nC4-016 run complete. Return console output and the requested summary/manifest/comparison JSON files from .\outputs\ to ChatGPT."
