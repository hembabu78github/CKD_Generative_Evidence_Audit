$ErrorActionPreference = "Stop"
Write-Host "=== C4-010 environment ==="
python --version
Write-Host "`n=== Integrated C4-006 through C4-010 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-010 deterministic exception assembly and precedence ==="
python run_c4_010_validation.py
Write-Host "`nC4-010 run complete. Return console output and the two requested JSON files from .\outputs\ to ChatGPT."
