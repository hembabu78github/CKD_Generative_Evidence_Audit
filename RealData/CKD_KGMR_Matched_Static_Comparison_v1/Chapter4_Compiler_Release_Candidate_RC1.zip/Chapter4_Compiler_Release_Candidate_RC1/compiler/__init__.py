from .models import ClinicalPropositionIR, OperatorSelectionResult
from .selection import select_operators
from .version import COMPILER_VERSION
