import argparse,csv,json
from pathlib import Path
from compiler.static_validation import validate_static_bundle,validate_shared_runtime

def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def main():
    p=argparse.ArgumentParser(description="C4-015 static validation of complete CandidateMR/code package")
    p.add_argument("--candidate-dir",default="fixtures/c4_013_candidate_specs")
    p.add_argument("--codegen-manifest",default="fixtures/researcher_c4_014_codegen_manifest.json")
    p.add_argument("--c4-013-manifest",default="fixtures/researcher_c4_013_candidate_manifest.json")
    p.add_argument("--gate-results",default="fixtures/researcher_c4_014_end_to_end_gate_results.json")
    p.add_argument("--generated-module-dir",default="fixtures/researcher_c4_014_generated_modules")
    p.add_argument("--runtime",default="runtime/executable_runtime.py")
    p.add_argument("--runtime-config",default="config/executable_runtime_r1.json")
    p.add_argument("--policy",default="config/static_validation_policy_r1.json")
    p.add_argument("--output-dir",default="outputs")
    args=p.parse_args()

    policy=load(args.policy)
    runtime_cfg=load(args.runtime_config)
    manifest=load(args.codegen_manifest)["modules"]
    c13_rows=load(args.c4_013_manifest)["candidates"]
    c13_map={x["candidate_mr_id"]:x for x in c13_rows}
    gates=load(args.gate_results)["results"]
    gate_map={x["candidate_mr_id"]:x for x in gates}

    results=[]
    for m in sorted(manifest,key=lambda x:x["candidate_mr_id"]):
        cid=m["candidate_mr_id"]
        spec_path=Path(args.candidate_dir)/(cid+".json")
        yaml_path=Path(args.candidate_dir)/(cid+".yaml")
        module_path=Path(args.generated_module_dir)/m["module_path"]
        if cid not in gate_map:
            raise SystemExit("Missing researcher end-to-end gate result for "+cid)
        if cid not in c13_map:
            raise SystemExit("Missing researcher C4-013 manifest row for "+cid)
        if not spec_path.exists() or not yaml_path.exists() or not module_path.exists():
            raise SystemExit("Missing bundle file for "+cid)
        spec=load(spec_path)
        results.append(validate_static_bundle(
            spec,m,c13_map[cid],gate_map[cid],module_path,yaml_path,policy,runtime_cfg
        ))

    runtime_result=validate_shared_runtime(Path(args.runtime),policy)

    # Global uniqueness/integrity checks.
    ids=[x["candidate_mr_id"] for x in results]
    module_names=[x["module_name"] for x in manifest]
    module_hashes=[x["generated_python_sha256"] for x in manifest]
    global_checks={
      "candidate_ids_unique":len(ids)==len(set(ids)),
      "module_names_unique":len(module_names)==len(set(module_names)),
      "module_hashes_unique":len(module_hashes)==len(set(module_hashes)),
      "manifest_candidate_count_matches_gate_count":len(manifest)==len(gates)==len(results),
      "shared_runtime_compile_pass":runtime_result["compile_pass"],
      "shared_runtime_ast_safety_pass":runtime_result["ast_safety_pass"],
    }

    out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    (out/"c4_015_static_validation_results.json").write_text(
      json.dumps({"results":results},indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"c4_015_shared_runtime_validation.json").write_text(
      json.dumps(runtime_result,indent=2,sort_keys=True),encoding="utf-8"
    )

    rejection=[
      {
        "candidate_mr_id":x["candidate_mr_id"],
        "candidate_key":x["candidate_key"],
        "errors":x["errors"]
      }
      for x in results if x["static_validation_status"]!="STATIC_VALIDATION_PASS"
    ]
    (out/"c4_015_static_rejection_ledger.json").write_text(
      json.dumps({"rejections":rejection},indent=2,sort_keys=True),encoding="utf-8"
    )

    registry=[
      {
        "candidate_mr_id":x["candidate_mr_id"],
        "candidate_key":x["candidate_key"],
        "operator_id":x["operator_id"],
        "static_validation_status":x["static_validation_status"],
        "execution_admission_status":x["execution_admission_status"],
        "expert_validation_status":x["expert_validation_status"],
        "semantic_spec_fingerprint":x["semantic_spec_fingerprint"],
        "generated_module_sha256":x["generated_module_sha256"]
      }
      for x in results
    ]
    (out/"c4_015_static_validation_registry.json").write_text(
      json.dumps({"candidates":registry},indent=2,sort_keys=True),encoding="utf-8"
    )

    summary={
      "task":"C4-015",
      "candidate_bundle_count":len(results),
      "static_validation_pass_count":sum(x["static_validation_status"]=="STATIC_VALIDATION_PASS" for x in results),
      "static_validation_fail_count":sum(x["static_validation_status"]!="STATIC_VALIDATION_PASS" for x in results),
      "execution_admissible_after_static_validation_count":sum(
        x["execution_admission_status"]=="STATICALLY_VALID_EXECUTION_ADMISSIBLE" for x in results
      ),
      "control_blocked_after_static_validation_count":sum(
        x["execution_admission_status"]=="STATICALLY_VALID_BUT_CONTROL_BLOCKED" for x in results
      ),
      "expert_validation_unreviewed_count":sum(x["expert_validation_status"]=="UNREVIEWED" for x in results),
      "candidate_check_total":sum(x["check_count"] for x in results),
      "candidate_failed_check_total":sum(x["failed_check_count"] for x in results),
      "static_rejection_count":len(rejection),
      "shared_runtime_compile_pass":runtime_result["compile_pass"],
      "shared_runtime_ast_safety_pass":runtime_result["ast_safety_pass"],
      "candidate_ids_unique":global_checks["candidate_ids_unique"],
      "module_names_unique":global_checks["module_names_unique"],
      "module_hashes_unique":global_checks["module_hashes_unique"],
      "manifest_candidate_count_matches_gate_count":global_checks["manifest_candidate_count_matches_gate_count"],
      "static_validation_equals_clinical_validation":False,
      "static_validation_overrides_control_abstention":False,
      "all_global_checks_pass":all(global_checks.values()),
      "note":"Software static-validation fixtures only. A static PASS does not constitute expert clinical validation or override an upstream ABSTAIN."
    }
    (out/"c4_015_validation_summary.json").write_text(
      json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8"
    )

    with (out/"c4_015_static_validation_registry.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["candidate_mr_id","candidate_key","operator_id","static_validation_status",
                    "execution_admission_status","expert_validation_status"])
        for x in registry:
            w.writerow([x["candidate_mr_id"],x["candidate_key"],x["operator_id"],
                        x["static_validation_status"],x["execution_admission_status"],
                        x["expert_validation_status"]])

    print(json.dumps(summary,indent=2))
    ok=(
      summary["static_validation_fail_count"]==0
      and summary["static_rejection_count"]==0
      and summary["candidate_failed_check_total"]==0
      and summary["all_global_checks_pass"]
      and summary["shared_runtime_compile_pass"]
      and summary["shared_runtime_ast_safety_pass"]
    )
    if not ok:
        raise SystemExit(2)

if __name__=="__main__":
    main()
