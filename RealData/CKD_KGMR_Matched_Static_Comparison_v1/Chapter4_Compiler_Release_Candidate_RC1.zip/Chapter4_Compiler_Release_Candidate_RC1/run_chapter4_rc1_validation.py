import argparse, json, subprocess, sys, hashlib, re
from pathlib import Path

def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def run_cmd(cmd, cwd):
    p=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True)
    return {
      "returncode":p.returncode,
      "stdout":p.stdout,
      "stderr":p.stderr
    }

def main():
    ap=argparse.ArgumentParser(description="Chapter 4 Compiler Release Candidate RC1 acceptance")
    ap.add_argument("--policy",default="config/chapter4_rc1_policy.json")
    ap.add_argument("--output-dir",default="outputs")
    args=ap.parse_args()

    root=Path(".").resolve()
    out=root/args.output_dir
    out.mkdir(parents=True,exist_ok=True)
    policy=load(root/args.policy)

    # A. Full integrated unit suite.
    tests=run_cmd([sys.executable,"-m","unittest","discover","-s","tests","-v"],root)
    m=re.search(r"Ran (\d+) tests",tests["stderr"])
    test_count=int(m.group(1)) if m else None
    tests_pass=(tests["returncode"]==0 and test_count is not None)

    # B. Fresh C4-016 deterministic replay.
    c16=run_cmd([sys.executable,"run_c4_016_validation.py"],root)
    c16_summary=load(out/"c4_016_validation_summary.json") if (out/"c4_016_validation_summary.json").exists() else {}

    # C. Compare to exact researcher C4-016 acceptance artifact bundled into RC1.
    researcher=load(root/"fixtures"/"researcher_c4_016_validation_summary.json")
    researcher_manifest=load(root/"fixtures"/"researcher_c4_016_reproducibility_manifest.json")
    replay_comparison=load(root/"fixtures"/"researcher_c4_016_replay_comparison.json")

    # D. Verify prior stage summaries that remain the acceptance basis.
    c14=load(root/"fixtures"/"researcher_c4_014_validation_summary.json")
    c15=load(root/"fixtures"/"researcher_c4_015_validation_summary.json")

    checks=[
      ("UNIT_TEST_SUITE_PASS",tests_pass,
       f"returncode={tests['returncode']};test_count={test_count}"),
      ("C4_016_FRESH_REPLAY_PASS",c16["returncode"]==0,
       f"returncode={c16['returncode']}"),
      ("CANDIDATE_COUNT",c16_summary.get("candidate_count")==12,
       str(c16_summary.get("candidate_count"))),
      ("REPLAY_RELEASE_SIGNATURE_MATCH",c16_summary.get("replay_release_signature_match") is True,
       str(c16_summary.get("replay_release_signature_match"))),
      ("RELEASE_SIGNATURE_EQUALS_RESEARCHER",
       c16_summary.get("release_signature")==researcher.get("release_signature")==policy["expected_reproducibility_signature"],
       str(c16_summary.get("release_signature"))),
      ("REPLAY_CANDIDATE_IDS_12",c16_summary.get("replay_candidate_id_match_count")==12,
       str(c16_summary.get("replay_candidate_id_match_count"))),
      ("REPLAY_SEMANTIC_FINGERPRINTS_12",c16_summary.get("replay_semantic_fingerprint_match_count")==12,
       str(c16_summary.get("replay_semantic_fingerprint_match_count"))),
      ("REPLAY_GENERATED_CODE_HASHES_12",c16_summary.get("replay_generated_python_hash_match_count")==12,
       str(c16_summary.get("replay_generated_python_hash_match_count"))),
      ("REPLAY_STATIC_STATUS_12",c16_summary.get("replay_static_status_match_count")==12,
       str(c16_summary.get("replay_static_status_match_count"))),
      ("REPLAY_ADMISSION_STATUS_12",c16_summary.get("replay_execution_admission_match_count")==12,
       str(c16_summary.get("replay_execution_admission_match_count"))),
      ("VERSION_INVENTORY_PASS",c16_summary.get("required_version_inventory_pass") is True,
       str(c16_summary.get("required_version_inventory_pass"))),
      ("CONTROLLED_IDENTITY_TESTS_PASS",c16_summary.get("controlled_identity_tests_pass") is True,
       str(c16_summary.get("controlled_identity_tests_pass"))),
      ("ENVIRONMENT_EXCLUDED_FROM_SIGNATURE",
       c16_summary.get("environment_metadata_excluded_from_release_signature") is True,
       str(c16_summary.get("environment_metadata_excluded_from_release_signature"))),

      ("C4_014_MODULES_12",c14.get("generated_python_module_count")==12,
       str(c14.get("generated_python_module_count"))),
      ("C4_014_ALL_11_OPERATORS",c14.get("all_11_frozen_operators_generated") is True,
       str(c14.get("all_11_frozen_operators_generated"))),
      ("C4_014_BLOCKED_CDS_CALLS_ZERO",c14.get("blocked_candidates_called_cds_count")==0,
       str(c14.get("blocked_candidates_called_cds_count"))),
      ("C4_015_STATIC_PASS_12",c15.get("static_validation_pass_count")==12,
       str(c15.get("static_validation_pass_count"))),
      ("C4_015_STATIC_FAIL_ZERO",c15.get("static_validation_fail_count")==0,
       str(c15.get("static_validation_fail_count"))),
      ("C4_015_EXECUTION_ADMISSIBLE_8",
       c15.get("execution_admissible_after_static_validation_count")==8,
       str(c15.get("execution_admissible_after_static_validation_count"))),
      ("C4_015_CONTROL_BLOCKED_4",
       c15.get("control_blocked_after_static_validation_count")==4,
       str(c15.get("control_blocked_after_static_validation_count"))),
      ("C4_015_EXPERT_UNREVIEWED_12",
       c15.get("expert_validation_unreviewed_count")==12,
       str(c15.get("expert_validation_unreviewed_count"))),

      ("RESEARCHER_ARTIFACT_COMPARISON_12",
       replay_comparison["researcher_artifact_comparison"]["candidate_count"]==12
       and replay_comparison["researcher_artifact_comparison"]["semantic_fingerprint_match_count"]==12
       and replay_comparison["researcher_artifact_comparison"]["generated_python_sha256_match_count"]==12
       and replay_comparison["researcher_artifact_comparison"]["static_validation_status_match_count"]==12,
       "C4-013/C4-014/C4-015 researcher artifact chain"),
    ]

    matrix=[
      {"check_id":name,"passed":passed,"detail":detail}
      for name,passed,detail in checks
    ]
    failed=[x for x in matrix if not x["passed"]]

    release_status="SOFTWARE_ENGINEERING_RC_ACCEPTED" if not failed else "SOFTWARE_ENGINEERING_RC_REJECTED"

    release_core={
      "release_candidate_id":policy["release_candidate_id"],
      "release_candidate_version":policy["release_candidate_version"],
      "pipeline_scope":policy["pipeline_scope"],
      "release_status":release_status,
      "reproducibility_signature":c16_summary.get("release_signature"),
      "candidate_count":12,
      "static_validation_pass_count":c15.get("static_validation_pass_count"),
      "execution_admissible_count":c15.get("execution_admissible_after_static_validation_count"),
      "control_blocked_count":c15.get("control_blocked_after_static_validation_count"),
      "expert_validation_unreviewed_count":c15.get("expert_validation_unreviewed_count"),
      "generated_python_module_count":c14.get("generated_python_module_count"),
      "unique_operator_count":c14.get("unique_operator_count"),
      "unit_test_count":test_count,
      "acceptance_check_count":len(matrix),
      "acceptance_failed_check_count":len(failed),
      "software_only":True,
    }
    rc_signature=hashlib.sha256(
      json.dumps(release_core,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")
    ).hexdigest()

    summary={
      "task":"CH4-RC1",
      **release_core,
      "chapter4_rc_signature":rc_signature,
      "clinical_validation_claimed":False,
      "expert_validation_claimed":False,
      "real_compiler_yield_claimed":False,
      "ready_for_next_phase":not failed,
      "next_phase":"evaluation_baseline_ablation_and_real_KG_integration",
      "note":"RC1 accepts the software-engineering compiler chain only. It does not establish clinical validity, expert acceptance, real CKD compiler yield, CDS robustness, or novelty."
    }

    (out/"chapter4_rc1_validation_summary.json").write_text(
      json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"chapter4_rc1_acceptance_matrix.json").write_text(
      json.dumps({"checks":matrix},indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"chapter4_rc1_release_manifest.json").write_text(
      json.dumps({
        "release_core":release_core,
        "chapter4_rc_signature":rc_signature,
        "researcher_c4_016_reproducibility_signature":researcher_manifest["reproducibility_signature"],
        "environment_observation":researcher_manifest["environment_observation"],
        "environment_in_release_signature":False,
        "interpretation":policy["interpretation"]
      },indent=2,sort_keys=True),encoding="utf-8"
    )

    # Preserve compact console logs for troubleshooting, without making them part of identity.
    (out/"chapter4_rc1_unit_test_console.txt").write_text(
      tests["stdout"]+"\n"+tests["stderr"],encoding="utf-8"
    )
    (out/"chapter4_rc1_c4_016_console.txt").write_text(
      c16["stdout"]+"\n"+c16["stderr"],encoding="utf-8"
    )

    print(json.dumps(summary,indent=2))
    if failed:
        print("\nFailed checks:")
        for x in failed:
            print(" -",x["check_id"],x["detail"])
        raise SystemExit(2)

if __name__=="__main__":
    main()
