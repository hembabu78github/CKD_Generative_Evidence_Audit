$ErrorActionPreference = "Stop"
Write-Host "=== C4-008 environment ==="
python --version
Write-Host "`n=== C4-006 + C4-008 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-008 deterministic component generation ==="
python run_c4_008_validation.py
Write-Host "`nC4-008 run complete. Return console output and the two requested JSON files from .\outputs\ to ChatGPT."
