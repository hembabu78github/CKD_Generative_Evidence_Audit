import argparse,csv,json
from pathlib import Path
from compiler.conflict_io import load_components,load_scopes,load_result_map,load_conflict_evidence
from compiler.output_relation_typing import final_type_relation
from compiler.conflict_detection import (
  candidate_key,detect_expected_relation_conflicts,detect_temporal_conflicts,
  records_from_explicit_evidence,detect_duplicates
)

def main():
    p=argparse.ArgumentParser(description="C4-012 conflict detection and final output-relation typing")
    p.add_argument("--components",default="fixtures/researcher_c4_008_component_generation_results.json")
    p.add_argument("--invariants",default="fixtures/researcher_c4_009_invariant_inference_results.json")
    p.add_argument("--exceptions",default="fixtures/researcher_c4_010_exception_precedence_results.json")
    p.add_argument("--temporal",default="fixtures/researcher_c4_011_temporal_satisfiability_results.json")
    p.add_argument("--scopes",default="fixtures/c4_012_candidate_scope_registry.json")
    p.add_argument("--taxonomy-tests",default="fixtures/c4_012_conflict_taxonomy_test_cases.json")
    p.add_argument("--output-dir",default="outputs")
    args=p.parse_args()

    comps=load_components(args.components)
    inv=load_result_map(args.invariants)
    exc=load_result_map(args.exceptions)
    temp=load_result_map(args.temporal)
    scopes=load_scopes(args.scopes)

    typed=[final_type_relation(c) for c in sorted(comps,key=lambda x:(x["proposition_id"],x["operator_id"]))]
    typed_by_key={candidate_key(x.proposition_id,x.operator_id):x for x in typed}

    expected=detect_expected_relation_conflicts(typed,scopes,exc,temp)
    temporal_conflicts=detect_temporal_conflicts(typed,scopes,temp)
    integrated_conflicts=expected+temporal_conflicts

    duplicates=detect_duplicates(comps,typed_by_key,inv,exc,scopes)

    # Separate synthetic taxonomy validation. These records are NEVER mixed into integrated conflict counts.
    taxonomy_evidence=load_conflict_evidence(args.taxonomy_tests)
    taxonomy_records=records_from_explicit_evidence(taxonomy_evidence,{})

    # Repeat integrated computations for deterministic fingerprints.
    typed2=[final_type_relation(c) for c in sorted(comps,key=lambda x:(x["proposition_id"],x["operator_id"]))]
    expected2=detect_expected_relation_conflicts(typed2,scopes,exc,temp)
    temporal2=detect_temporal_conflicts(typed2,scopes,temp)
    int_fp=[x.conflict_id for x in integrated_conflicts]
    int_fp2=[x.conflict_id for x in expected2+temporal2]
    typed_sig=[x.relation_signature for x in typed]
    typed_sig2=[x.relation_signature for x in typed2]
    deterministic=(int_fp==int_fp2 and typed_sig==typed_sig2)

    out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    (out/"c4_012_output_relation_typing_results.json").write_text(
      json.dumps({"results":[x.to_dict() for x in typed]},indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"c4_012_integrated_conflict_records.json").write_text(
      json.dumps({"records":[x.to_dict() for x in integrated_conflicts]},indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"c4_012_duplicate_records.json").write_text(
      json.dumps({"records":[x.to_dict() for x in duplicates]},indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"c4_012_taxonomy_validation_records.json").write_text(
      json.dumps({"records":[x.to_dict() for x in taxonomy_records]},indent=2,sort_keys=True),encoding="utf-8"
    )

    integrated_types=sorted({x.conflict_type for x in integrated_conflicts})
    taxonomy_types=sorted({x.conflict_type for x in taxonomy_records})
    summary={
      "task":"C4-012",
      "candidate_component_count":len(comps),
      "final_typed_relation_count":sum(x.typing_status=="FINAL_TYPED" for x in typed),
      "invalid_relation_type_count":sum(x.typing_status!="FINAL_TYPED" for x in typed),
      "formal_relation_families_present":sorted({x.relation_family for x in typed}),
      "integrated_detected_conflict_count":len(integrated_conflicts),
      "integrated_detected_conflict_types":integrated_types,
      "integrated_duplicate_group_count":len(duplicates),
      "taxonomy_validation_case_count":len(taxonomy_records),
      "all_ten_frozen_conflict_types_exercised":set(taxonomy_types)=={
        "ExpectedRelationConflict","ApplicabilityConflict","ExceptionConflict","VersionConflict",
        "TerminologyConflict","DataConflict","TemporalConflict","DecisionPolicyConflict",
        "SourceInterpretationConflict","ReviewConflict"
      },
      "nonstrict_opposing_monotonic_relations_automatically_conflicting":False,
      "nonstrict_opposing_ordinal_relations_automatically_conflicting":False,
      "cross_transformation_relations_compared_without_explicit_context_equivalence":False,
      "guideline_strength_automatic_tiebreak_used":False,
      "lexical_specificity_used":False,
      "deterministic_repeat_pass":deterministic,
      "typed_relation_signature_match_count":sum(a==b for a,b in zip(typed_sig,typed_sig2)),
      "integrated_conflict_id_match_count":sum(a==b for a,b in zip(int_fp,int_fp2)),
      "note":"Integrated and taxonomy counts are software-validation fixtures only; they are not clinical conflict prevalence or expert-valid MR results."
    }
    (out/"c4_012_validation_summary.json").write_text(
      json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8"
    )

    with (out/"c4_012_relation_typing_summary.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["proposition_id","operator_id","typing_status","relation_family","semantic_domain","relation_signature"])
        for x in typed:
            w.writerow([x.proposition_id,x.operator_id,x.typing_status,x.relation_family,x.semantic_domain,x.relation_signature])

    print(json.dumps(summary,indent=2))
    if not deterministic or summary["invalid_relation_type_count"]!=0 or not summary["all_ten_frozen_conflict_types_exercised"]:
        raise SystemExit(2)

if __name__=="__main__":
    main()
