# Chapter 4 Compiler Release Candidate RC1

This package is the consolidated engineering acceptance bundle for C4-006 through C4-016.

Run one command on Windows:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_chapter4_rc1_windows.ps1
```

If RC1 passes, the deterministic compiler engineering interface is frozen and the project
moves to evaluation, baselines, ablations, real CKD-TKG integration, and thesis results.

RC1 is software-engineering acceptance only; it is not expert clinical validation.
