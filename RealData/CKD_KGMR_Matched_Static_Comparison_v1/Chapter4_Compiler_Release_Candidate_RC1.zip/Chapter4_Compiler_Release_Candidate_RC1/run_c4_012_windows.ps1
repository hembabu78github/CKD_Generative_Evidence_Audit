$ErrorActionPreference = "Stop"
Write-Host "=== C4-012 environment ==="
python --version
Write-Host "`n=== Integrated C4-006 through C4-012 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-012 deterministic conflict detection and final relation typing ==="
python run_c4_012_validation.py
Write-Host "`nC4-012 run complete. Return console output and the requested JSON files from .\outputs\ to ChatGPT."
