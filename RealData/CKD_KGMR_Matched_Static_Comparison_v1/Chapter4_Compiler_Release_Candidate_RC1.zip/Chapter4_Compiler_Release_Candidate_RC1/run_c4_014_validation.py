import argparse,csv,importlib.util,json,py_compile,shutil
from pathlib import Path
from compiler.python_codegen import generate_modules,semantic_fp

def load(p): return json.loads(Path(p).read_text(encoding="utf-8"))
def load_module(path,name):
    s=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

def main():
    a=argparse.ArgumentParser()
    a.add_argument("--spec-dir",default="fixtures/c4_013_candidate_specs")
    a.add_argument("--manifest",default="fixtures/researcher_c4_013_candidate_manifest.json")
    a.add_argument("--execution-cases",default="fixtures/c4_014_execution_cases.json")
    a.add_argument("--runtime-config",default="config/executable_runtime_r1.json")
    a.add_argument("--output-dir",default="outputs")
    args=a.parse_args()

    manifest=load(args.manifest)["candidates"]
    cases={x["candidate_key"]:x for x in load(args.execution_cases)["cases"]}
    cfg=load(args.runtime_config)
    out=Path(args.output_dir)
    generated=out/"generated_mr_python"
    if generated.exists(): shutil.rmtree(generated)
    generated.mkdir(parents=True,exist_ok=True)

    semantic_matches=0
    for m in manifest:
        spec=load(Path(args.spec_dir)/f"{m['candidate_mr_id']}.json")
        semantic_matches+=int(semantic_fp(spec)==m["semantic_spec_fingerprint"])

    rows=generate_modules(args.spec_dir,manifest,generated)
    compile_pass=0
    for row in rows:
        py_compile.compile(str(generated/row["module_path"]),doraise=True)
        compile_pass+=1

    repeat=out/"generated_mr_python_repeat"
    if repeat.exists(): shutil.rmtree(repeat)
    rows2=generate_modules(args.spec_dir,manifest,repeat)
    h1=[x["generated_python_sha256"] for x in rows]
    h2=[x["generated_python_sha256"] for x in rows2]
    deterministic=h1==h2
    shutil.rmtree(repeat)

    direct=[]
    e2e=[]
    for row in rows:
        c=cases[row["candidate_key"]]
        mod=load_module(generated/row["module_path"],row["module_name"]+"_run")
        before=json.loads(json.dumps(c["source_case"]))
        follow=mod.transform(c["source_case"],c.get("execution_context",{}),cfg)
        unchanged=(c["source_case"]==before)
        oracle=mod.oracle(c["source_output"],c["followup_output"],c.get("oracle_context",{}),cfg)
        direct.append({
          "candidate_mr_id":row["candidate_mr_id"],"candidate_key":row["candidate_key"],
          "operator_id":row["operator_id"],"execution_gate":row["execution_gate"],
          "source_case_unchanged":unchanged,"oracle_truth":oracle["truth"],
          "expected_oracle_truth":c["expected_oracle_truth"],
          "direct_smoke_pass":unchanged and oracle["truth"]==c["expected_oracle_truth"]
        })

        calls={"n":0}
        def cds(_):
            calls["n"]+=1
            return c["source_output"] if calls["n"]==1 else c["followup_output"]
        result=mod.execute(c["source_case"],cds,c.get("execution_context",{}),c.get("oracle_context",{}),cfg)
        if row["execution_gate"]=="PROCEED":
            passed=(result["status"]=="EXECUTED" and calls["n"]==2 and result["oracle"]["truth"]==c["expected_oracle_truth"])
        else:
            passed=(result["status"]=="ABSTAIN" and calls["n"]==0)
        e2e.append({
          "candidate_mr_id":row["candidate_mr_id"],"candidate_key":row["candidate_key"],
          "execution_gate":row["execution_gate"],"result_status":result["status"],
          "cds_call_count":calls["n"],"pass":passed
        })

    (out/"c4_014_codegen_manifest.json").write_text(json.dumps({"modules":rows},indent=2,sort_keys=True),encoding="utf-8")
    (out/"c4_014_direct_smoke_results.json").write_text(json.dumps({"results":direct},indent=2,sort_keys=True),encoding="utf-8")
    (out/"c4_014_end_to_end_gate_results.json").write_text(json.dumps({"results":e2e},indent=2,sort_keys=True),encoding="utf-8")

    summary={
      "task":"C4-014",
      "source_candidate_spec_count":len(manifest),
      "researcher_manifest_semantic_fingerprint_match_count":semantic_matches,
      "generated_python_module_count":len(rows),
      "generated_python_compile_pass_count":compile_pass,
      "unique_operator_count":len({x["operator_id"] for x in rows}),
      "execution_gate_proceed_count":sum(x["execution_gate"]=="PROCEED" for x in rows),
      "execution_gate_abstain_count":sum(x["execution_gate"]=="ABSTAIN" for x in rows),
      "direct_transformation_oracle_smoke_count":len(direct),
      "direct_transformation_oracle_smoke_pass_count":sum(x["direct_smoke_pass"] for x in direct),
      "source_case_immutability_pass_count":sum(x["source_case_unchanged"] for x in direct),
      "end_to_end_gate_smoke_count":len(e2e),
      "end_to_end_gate_smoke_pass_count":sum(x["pass"] for x in e2e),
      "blocked_candidates_called_cds_count":sum(x["cds_call_count"] for x in e2e if x["execution_gate"]=="ABSTAIN"),
      "generated_source_repeat_pass":deterministic,
      "generated_source_hash_match_count":sum(a==b for a,b in zip(h1,h2)),
      "all_11_frozen_operators_generated":len({x["operator_id"] for x in rows})==11,
      "code_generation_equals_clinical_validation":False,
      "note":"Software-validation execution fixtures only. Generated modules are not clinically validated CDS tests."
    }
    (out/"c4_014_validation_summary.json").write_text(json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8")
    print(json.dumps(summary,indent=2))
    ok=(semantic_matches==len(manifest) and compile_pass==len(rows)
        and all(x["direct_smoke_pass"] for x in direct)
        and all(x["pass"] for x in e2e)
        and summary["blocked_candidates_called_cds_count"]==0
        and deterministic and summary["all_11_frozen_operators_generated"])
    if not ok: raise SystemExit(2)

if __name__=="__main__":
    main()
