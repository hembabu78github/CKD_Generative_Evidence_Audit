import argparse,csv,json
from pathlib import Path
from compiler.exception_io import load_config,load_exception_inputs,load_components,load_invariants
from compiler.exception_precedence import resolve_exception_precedence

def main():
    p=argparse.ArgumentParser(description="C4-010 exception assembly and P0-P8 precedence validation")
    p.add_argument("--components",default="fixtures/researcher_c4_008_component_generation_results.json")
    p.add_argument("--invariants",default="fixtures/researcher_c4_009_invariant_inference_results.json")
    p.add_argument("--inputs",default="fixtures/c4_010_exception_precedence_inputs.json")
    p.add_argument("--config",default="config/exception_precedence_c3_013_r1.json")
    p.add_argument("--output-dir",default="outputs")
    args=p.parse_args()

    config=load_config(args.config)
    evidence,contexts=load_exception_inputs(args.inputs)
    components=load_components(args.components)
    invariants=load_invariants(args.invariants)

    results=[]
    for comp in sorted(components,key=lambda x:(x["proposition_id"],x["operator_id"])):
        key=(comp["proposition_id"],comp["operator_id"])
        if key not in contexts:
            continue
        if key not in invariants:
            raise SystemExit(f"Missing C4-009 upstream invariant result for {key}")
        r=resolve_exception_precedence(
            comp["proposition_id"],comp["operator_id"],evidence,contexts[key],config
        )
        d=r.to_dict()
        d["c4_008_component_fingerprint"]=comp["component_fingerprint"]
        d["c4_009_invariant_fingerprint"]=invariants[key]["invariant_fingerprint"]
        results.append(d)

    results2=[]
    for comp in sorted(components,key=lambda x:(x["proposition_id"],x["operator_id"])):
        key=(comp["proposition_id"],comp["operator_id"])
        if key in contexts and key in invariants:
            r=resolve_exception_precedence(
                comp["proposition_id"],comp["operator_id"],evidence,contexts[key],config
            )
            results2.append((r.proposition_id,r.operator_id,r.exception_fingerprint))

    fp1=[(x["proposition_id"],x["operator_id"],x["exception_fingerprint"]) for x in results]
    deterministic=fp1==results2

    out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    (out/"c4_010_exception_precedence_results.json").write_text(
        json.dumps({"results":results},indent=2,sort_keys=True),encoding="utf-8"
    )

    assembled=sum(len(x["assembled_exceptions"]) for x in results)
    active=sum(
      1 for x in results for e in x["assembled_exceptions"]
      if e["condition"]["observed_fixture_truth"] in {"TRUE","INDETERMINATE"}
    )
    summary={
      "task":"C4-010",
      "component_count":len(results),
      "assembled_exception_count":assembled,
      "active_or_indeterminate_exception_count":active,
      "deterministic_repeat_pass":deterministic,
      "fingerprint_match_count":len(fp1) if deterministic else sum(a==b for a,b in zip(fp1,results2)),
      "outcome_counts":{},
      "all_ten_frozen_exception_types_exercised":
          set(config["exception_types"]) <= set(e["exception_type"] for e in [x for x in json.loads(Path(args.inputs).read_text())["exceptions"]]),
      "precedence_tiers_frozen":[f"P{i}" for i in range(9)],
      "guideline_strength_automatic_tiebreak_used":False,
      "lexical_specificity_used":False,
      "unresolved_conflict_action":"ABSTAIN/INDETERMINATE",
      "note":"Software-validation fixtures only; not clinical MR-performance or conflict-frequency results."
    }
    for x in results:
        summary["outcome_counts"][x["precedence_outcome"]]=summary["outcome_counts"].get(x["precedence_outcome"],0)+1

    (out/"c4_010_validation_summary.json").write_text(
        json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8"
    )
    with (out/"c4_010_exception_precedence_summary.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["proposition_id","operator_id","assembled_exception_count","precedence_outcome",
                    "semantic_truth","system_action","conflict_resolved_gate","exception_fingerprint"])
        for x in results:
            w.writerow([x["proposition_id"],x["operator_id"],len(x["assembled_exceptions"]),
                        x["precedence_outcome"],x["semantic_truth"],x["system_action"],
                        x["conflict_resolved_gate"],x["exception_fingerprint"]])

    print(json.dumps(summary,indent=2))
    if not deterministic:
        raise SystemExit(2)

if __name__=="__main__":
    main()
