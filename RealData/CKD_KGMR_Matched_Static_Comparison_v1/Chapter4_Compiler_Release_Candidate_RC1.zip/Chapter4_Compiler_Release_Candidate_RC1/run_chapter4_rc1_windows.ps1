$ErrorActionPreference = "Stop"
Write-Host "=== Chapter 4 Compiler Release Candidate RC1 ==="
python --version
Write-Host "`n=== Consolidated RC1 acceptance ==="
python run_chapter4_rc1_validation.py
Write-Host "`nRC1 run complete."
Write-Host "Return:"
Write-Host "  outputs\chapter4_rc1_validation_summary.json"
Write-Host "  outputs\chapter4_rc1_acceptance_matrix.json"
Write-Host "  outputs\chapter4_rc1_release_manifest.json"
