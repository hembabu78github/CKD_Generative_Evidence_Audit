import argparse,csv,hashlib,json,shutil
from pathlib import Path
from compiler.candidate_assembly import build_candidate,semantic_fingerprint,key
from compiler.candidate_validation import validate_candidate
from compiler.deterministic_yaml import dumps_yaml_document

def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def result_map(path):
    return {key(x["proposition_id"],x["operator_id"]):x for x in load(path)["results"]}

def main():
    p=argparse.ArgumentParser(description="C4-013 deterministic CandidateMR-R1.0 JSON/YAML specification generation")
    p.add_argument("--components",default="fixtures/researcher_c4_008_component_generation_results.json")
    p.add_argument("--invariants",default="fixtures/researcher_c4_009_invariant_inference_results.json")
    p.add_argument("--exceptions",default="fixtures/researcher_c4_010_exception_precedence_results.json")
    p.add_argument("--temporal",default="fixtures/researcher_c4_011_temporal_satisfiability_results.json")
    p.add_argument("--typed-relations",default="fixtures/researcher_c4_012_output_relation_typing_results.json")
    p.add_argument("--conflicts",default="fixtures/researcher_c4_012_integrated_conflict_records.json")
    p.add_argument("--output-dir",default="outputs")
    args=p.parse_args()

    comps=load(args.components)["results"]
    inv=result_map(args.invariants)
    exc=result_map(args.exceptions)
    temp=result_map(args.temporal)
    typed=result_map(args.typed_relations)
    conflicts=load(args.conflicts)["records"]

    out=Path(args.output_dir)
    json_dir=out/"candidate_mr_json"
    yaml_dir=out/"candidate_mr_yaml"
    if json_dir.exists(): shutil.rmtree(json_dir)
    if yaml_dir.exists(): shutil.rmtree(yaml_dir)
    json_dir.mkdir(parents=True,exist_ok=True)
    yaml_dir.mkdir(parents=True,exist_ok=True)

    manifest=[]
    specs=[]
    invalid=[]
    for comp in sorted(comps,key=lambda x:(x["proposition_id"],x["operator_id"])):
        k=key(comp["proposition_id"],comp["operator_id"])
        missing=[name for name,m in [("I",inv),("E",exc),("TEMP",temp),("R",typed)] if k not in m]
        if missing:
            invalid.append({"candidate_key":k,"errors":["MISSING_UPSTREAM:"+",".join(missing)]})
            continue
        spec,control=build_candidate(comp,typed[k],inv[k],exc[k],temp[k],conflicts)
        errors=validate_candidate(spec)
        if errors:
            invalid.append({"candidate_key":k,"candidate_mr_id":spec["candidate_mr_id"],"errors":errors})
            continue

        js=json.dumps(spec,indent=2,sort_keys=True,ensure_ascii=False)+"\n"
        ys=dumps_yaml_document(spec)
        json_path=json_dir/f"{spec['candidate_mr_id']}.json"
        yaml_path=yaml_dir/f"{spec['candidate_mr_id']}.yaml"
        json_path.write_text(js,encoding="utf-8")
        yaml_path.write_text(ys,encoding="utf-8")

        fp=semantic_fingerprint(spec)
        control.update({
          "semantic_spec_fingerprint":fp,
          "json_sha256":hashlib.sha256(json_path.read_bytes()).hexdigest(),
          "yaml_sha256":hashlib.sha256(yaml_path.read_bytes()).hexdigest(),
          "json_path":str(json_path.relative_to(out)).replace("\\\\","/"),
          "yaml_path":str(yaml_path.relative_to(out)).replace("\\\\","/"),
          "validation_status":"VALID"
        })
        manifest.append(control)
        specs.append(spec)

    # Deterministic second pass in memory.
    specs2=[]
    for comp in sorted(comps,key=lambda x:(x["proposition_id"],x["operator_id"])):
        k=key(comp["proposition_id"],comp["operator_id"])
        if k in inv and k in exc and k in temp and k in typed:
            spec,_=build_candidate(comp,typed[k],inv[k],exc[k],temp[k],conflicts)
            if not validate_candidate(spec):
                specs2.append(spec)

    ids1=[x["candidate_mr_id"] for x in specs]
    ids2=[x["candidate_mr_id"] for x in specs2]
    fps1=[semantic_fingerprint(x) for x in specs]
    fps2=[semantic_fingerprint(x) for x in specs2]
    deterministic=(ids1==ids2 and fps1==fps2)

    (out/"c4_013_candidate_manifest.json").write_text(
      json.dumps({"candidates":manifest},indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"c4_013_rejection_ledger.json").write_text(
      json.dumps({"rejections":invalid},indent=2,sort_keys=True),encoding="utf-8"
    )

    summary={
      "task":"C4-013",
      "input_component_count":len(comps),
      "json_candidate_spec_count":len(specs),
      "yaml_candidate_spec_count":len(specs),
      "schema_semantic_validation_pass_count":len(specs),
      "generation_rejection_count":len(invalid),
      "all_specs_have_six_components":all(all(k in s for k in ["C","T","R","I","E","P"]) for s in specs),
      "all_specs_candidate_status_compiled":all(s["candidate_status"]=="COMPILED_CANDIDATE" for s in specs),
      "all_specs_expert_validation_unreviewed":all(s["P"]["mr_expert_validation_status"]=="UNREVIEWED" for s in specs),
      "fixture_observed_truth_leaked_into_exception_specs":any(
        "observed_fixture_truth" in json.dumps(s.get("E",[])) for s in specs
      ),
      "candidate_id_repeat_pass":ids1==ids2,
      "semantic_fingerprint_repeat_pass":fps1==fps2,
      "deterministic_repeat_pass":deterministic,
      "candidate_id_match_count":sum(a==b for a,b in zip(ids1,ids2)),
      "semantic_fingerprint_match_count":sum(a==b for a,b in zip(fps1,fps2)),
      "representation_version":"CandidateMR-R1.0",
      "schema_implementation":"CandidateMR-R1.0 / C4-013 schema patch 1",
      "note":"These are software-validation candidate specifications. They are not independently expert-validated MRs and must not be reported as clinical MR yield."
    }
    (out/"c4_013_validation_summary.json").write_text(
      json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8"
    )

    with (out/"c4_013_candidate_manifest.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["candidate_mr_id","candidate_key","operator_id","semantic_spec_fingerprint",
                    "validation_status","upstream_exception_system_action","upstream_temporal_truth"])
        for x in manifest:
            w.writerow([x["candidate_mr_id"],x["candidate_key"],x["operator_id"],
                        x["semantic_spec_fingerprint"],x["validation_status"],
                        x["upstream_exception_system_action"],x["upstream_temporal_truth"]])

    print(json.dumps(summary,indent=2))
    if not deterministic or invalid or summary["fixture_observed_truth_leaked_into_exception_specs"]:
        raise SystemExit(2)

if __name__=="__main__":
    main()
