import argparse, csv, json
from pathlib import Path
from compiler.io import load_ir_list, load_json, write_json
from compiler.selection import select_operators
from compiler.version import COMPILER_VERSION, OPERATOR_LIBRARY_VERSION, SREW_VERSION

def run(input_path, config_path, output_dir):
    irs = load_ir_list(input_path)
    cfg = load_json(config_path)

    # Two passes are intentional: identical fingerprints prove deterministic
    # operator ordering and parameter binding for identical inputs.
    pass1 = [select_operators(ir, cfg) for ir in irs]
    pass2 = [select_operators(ir, cfg) for ir in irs]
    deterministic = [a.selection_fingerprint == b.selection_fingerprint for a,b in zip(pass1, pass2)]

    results = [r.to_dict() for r in pass1]
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    write_json(out / "c4_006_operator_selection_results.json", {
        "compiler_version": COMPILER_VERSION,
        "operator_library_version": OPERATOR_LIBRARY_VERSION,
        "srew_version": SREW_VERSION,
        "results": results,
    })

    selected_count = sum(1 for r in pass1 if r.selection_status == "SELECTED")
    pending_admission = sum(1 for r in pass1 if r.admission_status == "PENDING")
    blocked_count = sum(1 for r in pass1 if r.selection_status == "BLOCKED")
    parameter_blocked = sum(1 for r in pass1 if r.selection_status == "PARAMETERIZATION_BLOCKED")
    summary = {
        "compiler_version": COMPILER_VERSION,
        "operator_library_version": OPERATOR_LIBRARY_VERSION,
        "fixture_count": len(pass1),
        "deterministic_repeat_pass": all(deterministic),
        "deterministic_fingerprint_matches": sum(deterministic),
        "selected_fixture_count": selected_count,
        "blocked_fixture_count": blocked_count,
        "parameterization_blocked_fixture_count": parameter_blocked,
        "pending_admission_fixture_count": pending_admission,
        "selected_operator_instances": sum(len(r.selected_operators) for r in pass1),
        "note": "These are software/unit-test fixture results, not clinical MR-performance results."
    }
    write_json(out / "c4_006_validation_summary.json", summary)

    with (out / "c4_006_operator_selection_summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["proposition_id","selection_status","admission_status","selected_operators","fingerprint"])
        for r in pass1:
            w.writerow([r.proposition_id, r.selection_status, r.admission_status,
                        "|".join(r.selected_operators), r.selection_fingerprint])

    print(json.dumps(summary, indent=2))
    if not all(deterministic):
        raise SystemExit(2)

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="C4-006 deterministic operator selection/parameterisation validation")
    p.add_argument("--input", default="fixtures/c4_006_ir_test_fixtures.json")
    p.add_argument("--config", default="config/compiler_config_r1.json")
    p.add_argument("--output-dir", default="outputs")
    args = p.parse_args()
    run(args.input, args.config, args.output_dir)
