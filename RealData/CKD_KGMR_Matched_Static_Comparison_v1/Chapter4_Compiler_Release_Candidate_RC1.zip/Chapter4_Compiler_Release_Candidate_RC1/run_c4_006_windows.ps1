$ErrorActionPreference = "Stop"
Write-Host "=== C4-006 environment ==="
python --version
Write-Host "`n=== C4-006 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-006 deterministic validation ==="
python run_c4_006_validation.py
Write-Host "`nC4-006 run complete. Return console output and files from .\outputs\ to ChatGPT."
