$ErrorActionPreference = "Stop"
Write-Host "=== C4-013 environment ==="
python --version
Write-Host "`n=== Integrated C4-006 through C4-013 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-013 deterministic CandidateMR JSON/YAML generation ==="
python run_c4_013_validation.py
Write-Host "`nC4-013 run complete. Return console output and the requested summary/manifest/rejection JSON files from .\outputs\ to ChatGPT."
