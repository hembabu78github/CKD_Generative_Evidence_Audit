$ErrorActionPreference = "Stop"
Write-Host "=== C4-015 environment ==="
python --version
Write-Host "`n=== Integrated C4-006 through C4-015 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-015 static validation of complete CandidateMR package ==="
python run_c4_015_validation.py
Write-Host "`nC4-015 run complete. Return console output and the requested summary/registry/rejection JSON files from .\outputs\ to ChatGPT."
