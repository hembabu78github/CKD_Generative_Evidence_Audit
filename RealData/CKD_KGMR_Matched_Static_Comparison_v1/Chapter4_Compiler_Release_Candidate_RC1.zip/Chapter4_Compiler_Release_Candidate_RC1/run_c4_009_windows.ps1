$ErrorActionPreference = "Stop"
Write-Host "=== C4-009 environment ==="
python --version
Write-Host "`n=== C4-006 + C4-008 + C4-009 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-009 deterministic invariant inference ==="
python run_c4_009_validation.py
Write-Host "`nC4-009 run complete. Return console output and the two requested JSON files from .\outputs\ to ChatGPT."
