$ErrorActionPreference = "Stop"
Write-Host "=== C4-011 environment ==="
python --version
Write-Host "`n=== Integrated C4-006 through C4-011 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-011 deterministic temporal satisfiability ==="
python run_c4_011_validation.py
Write-Host "`nC4-011 run complete. Return console output and the two requested JSON files from .\outputs\ to ChatGPT."
