import argparse, csv, json
from pathlib import Path
from compiler.invariant_io import load_neighbourhoods, load_c4_008_components
from compiler.invariant_inference import infer_invariants

def main():
    p = argparse.ArgumentParser(description="C4-009 invariant inference from explicit unaffected KG neighbourhood evidence")
    p.add_argument("--components", default="fixtures/researcher_c4_008_component_generation_results.json")
    p.add_argument("--neighbourhoods", default="fixtures/c4_009_neighbourhoods.json")
    p.add_argument("--output-dir", default="outputs")
    args = p.parse_args()

    components = load_c4_008_components(args.components)
    neighbourhoods = load_neighbourhoods(args.neighbourhoods)

    results = []
    for comp in sorted(components, key=lambda x:(x["proposition_id"], x["operator_id"])):
        n = neighbourhoods.get(comp["proposition_id"])
        if n is None:
            continue
        results.append(infer_invariants(comp, n).to_dict())

    # Repeat with same inputs; semantic fingerprints must match.
    results2 = []
    for comp in sorted(components, key=lambda x:(x["proposition_id"], x["operator_id"])):
        n = neighbourhoods.get(comp["proposition_id"])
        if n is None:
            continue
        results2.append(infer_invariants(comp, n).to_dict())

    fp1=[(x["proposition_id"],x["operator_id"],x["invariant_fingerprint"]) for x in results]
    fp2=[(x["proposition_id"],x["operator_id"],x["invariant_fingerprint"]) for x in results2]
    deterministic = fp1 == fp2

    out=Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out/"c4_009_invariant_inference_results.json").write_text(
        json.dumps({"results":results}, indent=2, sort_keys=True), encoding="utf-8"
    )

    total_inv=sum(len(x["inferred_invariants"]) for x in results)
    total_rej=sum(len(x["rejected_candidates"]) for x in results)
    summary={
      "task":"C4-009",
      "component_count":len(results),
      "components_with_invariants":sum(bool(x["inferred_invariants"]) for x in results),
      "inferred_invariant_count":total_inv,
      "rejected_supported_candidate_count":total_rej,
      "deterministic_repeat_pass":deterministic,
      "fingerprint_match_count":len(fp1) if deterministic else sum(a==b for a,b in zip(fp1,fp2)),
      "inference_policy":"explicit-positive-preservation-evidence + untouched-selector + no-dependency-to-touched-selector",
      "no_inference_from_silence":True,
      "note":"Software-validation fixtures only; not clinical MR-performance or clinical-validity results."
    }
    (out/"c4_009_validation_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )

    with (out/"c4_009_invariant_summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["proposition_id","operator_id","inference_status","invariant_count","rejected_count","invariant_fingerprint"])
        for x in results:
            w.writerow([
                x["proposition_id"],x["operator_id"],x["inference_status"],
                len(x["inferred_invariants"]),len(x["rejected_candidates"]),
                x["invariant_fingerprint"]
            ])

    print(json.dumps(summary, indent=2))
    if not deterministic:
        raise SystemExit(2)

if __name__=="__main__":
    main()
