$ErrorActionPreference = "Stop"
Write-Host "=== C4-014 environment ==="
python --version
Write-Host "`n=== Integrated C4-006 through C4-014 unit tests ==="
python -m unittest discover -s tests -v
Write-Host "`n=== C4-014 executable Python code generation and smoke validation ==="
python run_c4_014_validation.py
Write-Host "`nC4-014 run complete. Return console output and the requested summary/codegen/gate JSON files from .\outputs\ to ChatGPT."
