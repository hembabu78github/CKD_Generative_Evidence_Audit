import argparse,csv,json
from pathlib import Path
from compiler.temporal_io import load_temporal_cases,load_components,load_precedence_results
from compiler.temporal_satisfiability import check_temporal_satisfiability

def main():
    p=argparse.ArgumentParser(description="C4-011 temporal satisfiability validation")
    p.add_argument("--components",default="fixtures/researcher_c4_008_component_generation_results.json")
    p.add_argument("--precedence",default="fixtures/researcher_c4_010_exception_precedence_results.json")
    p.add_argument("--temporal-cases",default="fixtures/c4_011_temporal_cases.json")
    p.add_argument("--output-dir",default="outputs")
    args=p.parse_args()

    comps=load_components(args.components)
    prec=load_precedence_results(args.precedence)
    cases=load_temporal_cases(args.temporal_cases)

    results=[]
    for comp in sorted(comps,key=lambda x:(x["proposition_id"],x["operator_id"])):
        key=(comp["proposition_id"],comp["operator_id"])
        if key not in prec:
            raise SystemExit(f"Missing C4-010 precedence result for {key}")
        case=cases.get(comp["proposition_id"])
        if case is None:
            raise SystemExit(f"Missing temporal case for {comp['proposition_id']}")
        results.append(check_temporal_satisfiability(comp,prec[key],case).to_dict())

    results2=[]
    for comp in sorted(comps,key=lambda x:(x["proposition_id"],x["operator_id"])):
        key=(comp["proposition_id"],comp["operator_id"])
        case=cases[comp["proposition_id"]]
        r=check_temporal_satisfiability(comp,prec[key],case)
        results2.append((r.proposition_id,r.operator_id,r.temporal_fingerprint))
    fp1=[(x["proposition_id"],x["operator_id"],x["temporal_fingerprint"]) for x in results]
    deterministic=fp1==results2

    out=Path(args.output_dir); out.mkdir(parents=True,exist_ok=True)
    (out/"c4_011_temporal_satisfiability_results.json").write_text(
        json.dumps({"results":results},indent=2,sort_keys=True),encoding="utf-8"
    )

    summary={
      "task":"C4-011",
      "component_count":len(results),
      "temporally_satisfiable_count":sum(x["temporal_status"]=="TEMPORALLY_SATISFIABLE" for x in results),
      "temporally_indeterminate_count":sum(x["temporal_status"]=="TEMPORALLY_INDETERMINATE" for x in results),
      "temporally_unsatisfiable_count":sum(x["temporal_status"]=="TEMPORALLY_UNSATISFIABLE" for x in results),
      "invalid_temporal_input_count":sum(x["temporal_status"]=="INVALID_TEMPORAL_INPUT" for x in results),
      "constraint_evaluation_count":sum(len(x["constraint_evaluations"]) for x in results),
      "deterministic_repeat_pass":deterministic,
      "fingerprint_match_count":len(fp1) if deterministic else sum(a==b for a,b in zip(fp1,results2)),
      "half_open_interval_policy":True,
      "calendar_month_year_arithmetic":True,
      "indeterminate_coerced_to_false":False,
      "clinical_vs_availability_time_separated":True,
      "note":"Software-validation fixtures only; not clinical MR-performance or real temporal-failure rates."
    }
    (out/"c4_011_validation_summary.json").write_text(
        json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8"
    )
    with (out/"c4_011_temporal_summary.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["proposition_id","operator_id","temporal_status","temporal_truth","system_action",
                    "constraint_count","temporal_fingerprint"])
        for x in results:
            w.writerow([x["proposition_id"],x["operator_id"],x["temporal_status"],x["temporal_truth"],
                        x["system_action"],len(x["constraint_evaluations"]),x["temporal_fingerprint"]])

    print(json.dumps(summary,indent=2))
    if not deterministic or summary["invalid_temporal_input_count"]!=0:
        raise SystemExit(2)

if __name__=="__main__":
    main()
