import argparse, json, csv
from pathlib import Path
from compiler.component_io import load_component_inputs, load_selection_results
from compiler.component_generation import generate_components

def load_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def main():
    p = argparse.ArgumentParser(description="C4-008 precondition/transformation/output-relation generation validation")
    p.add_argument("--inputs", default="fixtures/c4_008_component_inputs.json")
    p.add_argument("--selection-results", default="fixtures/c4_006_operator_selection_results.json")
    p.add_argument("--contracts", default="config/transformation_contracts_r1.json")
    p.add_argument("--output-dir", default="outputs")
    args = p.parse_args()

    inputs = {x.proposition_id:x for x in load_component_inputs(args.inputs)}
    selections = load_selection_results(args.selection_results)
    contracts = load_json(args.contracts)

    results = []
    for proposition_id in sorted(inputs):
        if proposition_id not in selections:
            continue
        for result in generate_components(inputs[proposition_id], selections[proposition_id], contracts):
            results.append(result.to_dict())

    # Repeat generation to verify component-level fingerprints.
    results2 = []
    for proposition_id in sorted(inputs):
        if proposition_id not in selections:
            continue
        for result in generate_components(inputs[proposition_id], selections[proposition_id], contracts):
            results2.append(result.to_dict())

    fp1 = [(x["proposition_id"],x["operator_id"],x["component_fingerprint"]) for x in results]
    fp2 = [(x["proposition_id"],x["operator_id"],x["component_fingerprint"]) for x in results2]
    deterministic = fp1 == fp2

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out/"c4_008_component_generation_results.json").write_text(
        json.dumps({"results":results}, indent=2, sort_keys=True), encoding="utf-8"
    )

    summary = {
        "task":"C4-008",
        "component_result_count":len(results),
        "components_generated_count":sum(x["generation_status"]=="COMPONENTS_GENERATED" for x in results),
        "relation_typing_pending_count":sum(x["generation_status"]=="RELATION_TYPING_PENDING" for x in results),
        "invalid_count":sum(x["generation_status"]=="INVALID" for x in results),
        "deterministic_repeat_pass":deterministic,
        "fingerprint_match_count":len(fp1) if deterministic else sum(a==b for a,b in zip(fp1,fp2)),
        "relation_families_generated":sorted({
            x["R"]["relation_family"] for x in results if x["R"]["relation_family"] is not None
        }),
        "note":"Software-validation fixtures only; not clinical MR-performance results."
    }
    (out/"c4_008_validation_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )

    with (out/"c4_008_component_generation_summary.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w=csv.writer(f)
        w.writerow(["proposition_id","operator_id","generation_status","C_status","T_status","R_status","R_family","component_fingerprint"])
        for x in results:
            w.writerow([
                x["proposition_id"],x["operator_id"],x["generation_status"],
                x["C"]["status"],x["T"]["status"],x["R"]["status"],
                x["R"]["relation_family"] or "",
                x["component_fingerprint"]
            ])

    print(json.dumps(summary, indent=2))
    if not deterministic or summary["invalid_count"] != 0:
        raise SystemExit(2)

if __name__ == "__main__":
    main()
