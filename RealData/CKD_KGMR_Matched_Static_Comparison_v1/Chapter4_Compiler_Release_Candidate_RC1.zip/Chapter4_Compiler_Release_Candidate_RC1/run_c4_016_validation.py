import argparse,json,shutil
from pathlib import Path
from compiler.reproducibility import (
  replay_once,compare_replays,compare_to_researcher,
  controlled_identity_tests,required_version_check
)

def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))

def main():
    p=argparse.ArgumentParser(description="C4-016 deterministic replay and version tracking")
    p.add_argument("--policy",default="config/reproducibility_policy_r1.json")
    p.add_argument("--output-dir",default="outputs")
    args=p.parse_args()

    root=Path(".").resolve()
    policy=load(args.policy)
    out=Path(args.output_dir)
    out.mkdir(parents=True,exist_ok=True)
    work=out/"c4_016_replay_work"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir()

    a=replay_once(root,work/"replay_a",policy)
    b=replay_once(root,work/"replay_b",policy)
    replay_cmp=compare_replays(a,b)
    researcher_cmp=compare_to_researcher(root,a)
    identity_tests=controlled_identity_tests(a["candidate_specs"][0])
    version_check=required_version_check(a["release_core"]["versions"],policy["required_versions"])

    # Release manifest is deterministic core + observed environment kept explicitly outside signature.
    manifest={
      "release_core":a["release_core"],
      "reproducibility_signature":a["reproducibility_signature"],
      "environment_observation":a["environment_observation"],
      "environment_in_release_signature":False
    }
    (out/"c4_016_reproducibility_manifest.json").write_text(
      json.dumps(manifest,indent=2,sort_keys=True),encoding="utf-8"
    )
    comparison={
      "replay_comparison":replay_cmp,
      "researcher_artifact_comparison":researcher_cmp,
      "controlled_identity_tests":identity_tests,
      "required_version_check":version_check,
    }
    (out/"c4_016_replay_comparison.json").write_text(
      json.dumps(comparison,indent=2,sort_keys=True),encoding="utf-8"
    )
    (out/"c4_016_version_inventory.json").write_text(
      json.dumps(a["release_core"]["versions"],indent=2,sort_keys=True),encoding="utf-8"
    )

    summary={
      "task":"C4-016",
      "replay_count":2,
      "candidate_count":a["release_core"]["candidate_count"],
      "replay_release_signature_match":replay_cmp["release_signature_match"],
      "replay_candidate_id_match_count":replay_cmp["candidate_id_match_count"],
      "replay_semantic_fingerprint_match_count":replay_cmp["semantic_fingerprint_match_count"],
      "replay_generated_python_hash_match_count":replay_cmp["generated_python_hash_match_count"],
      "replay_static_status_match_count":replay_cmp["static_status_match_count"],
      "replay_execution_admission_match_count":replay_cmp["execution_admission_match_count"],
      "researcher_c4_013_candidate_id_match_count":researcher_cmp["researcher_c4_013_id_match_count"],
      "researcher_c4_013_semantic_fingerprint_match_count":researcher_cmp["semantic_fingerprint_match_count"],
      "researcher_c4_014_generated_python_sha256_match_count":researcher_cmp["generated_python_sha256_match_count"],
      "researcher_c4_015_static_status_match_count":researcher_cmp["static_validation_status_match_count"],
      "researcher_c4_015_execution_admission_match_count":researcher_cmp["execution_admission_status_match_count"],
      "researcher_c4_015_expert_status_match_count":researcher_cmp["expert_validation_status_match_count"],
      "required_version_inventory_pass":all(version_check.values()),
      "controlled_identity_tests_pass":all(identity_tests.values()),
      "environment_metadata_excluded_from_release_signature":True,
      "release_signature":a["reproducibility_signature"],
      "note":"Software reproducibility fixtures only. Matching deterministic artifacts do not constitute expert clinical validation."
    }
    (out/"c4_016_validation_summary.json").write_text(
      json.dumps(summary,indent=2,sort_keys=True),encoding="utf-8"
    )

    # Keep only deterministic reports, not bulky replay working directories.
    shutil.rmtree(work)

    print(json.dumps(summary,indent=2))
    ok=(
      summary["candidate_count"]==12
      and summary["replay_release_signature_match"]
      and summary["replay_candidate_id_match_count"]==12
      and summary["replay_semantic_fingerprint_match_count"]==12
      and summary["replay_generated_python_hash_match_count"]==12
      and summary["replay_static_status_match_count"]==12
      and summary["replay_execution_admission_match_count"]==12
      and summary["researcher_c4_013_candidate_id_match_count"]==12
      and summary["researcher_c4_013_semantic_fingerprint_match_count"]==12
      and summary["researcher_c4_014_generated_python_sha256_match_count"]==12
      and summary["researcher_c4_015_static_status_match_count"]==12
      and summary["researcher_c4_015_execution_admission_match_count"]==12
      and summary["researcher_c4_015_expert_status_match_count"]==12
      and summary["required_version_inventory_pass"]
      and summary["controlled_identity_tests_pass"]
      and summary["environment_metadata_excluded_from_release_signature"]
    )
    if not ok:
        raise SystemExit(2)

if __name__=="__main__":
    main()
